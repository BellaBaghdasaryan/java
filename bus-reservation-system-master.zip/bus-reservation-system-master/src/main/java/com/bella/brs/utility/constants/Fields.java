package com.bella.brs.utility.constants;

/**
 * @author Bella Baghdasaryan
 */
public class Fields {
	public static final String ID = "id";
}
