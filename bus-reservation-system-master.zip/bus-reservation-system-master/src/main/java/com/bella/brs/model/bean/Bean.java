package com.bella.brs.model.bean;

import com.bella.brs.model.Model;

/**
 * @author Bella Baghdasaryan
 */
public interface Bean extends Model{}