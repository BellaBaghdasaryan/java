package com.bella.brs.model;

/**
 * @author Bella Baghdasaryan
 */
public interface Model{}