package com.bella.brs.utility.constants;

/**
 * @author Bella Baghdasaryan
 */
public class ResourcePaths {
	public static final String BANNER = "/images/banner.jpg";
	public static final String REDSEAT = "/images/redSeat.jpg";
	public static final String GREENSEAT = "/images/greenSeat.jpg";
}
