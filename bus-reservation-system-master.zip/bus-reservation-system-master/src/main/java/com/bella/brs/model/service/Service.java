package com.bella.brs.model.service;

/**
 * @author Bella Baghdasaryan
 */
public interface Service {

}
