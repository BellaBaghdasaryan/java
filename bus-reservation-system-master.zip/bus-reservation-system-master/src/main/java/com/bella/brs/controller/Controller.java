package com.bella.brs.controller;


/**
 * @author Bella Baghdasaryan
 */
public interface Controller{
	public void control(Controller parentController);
}