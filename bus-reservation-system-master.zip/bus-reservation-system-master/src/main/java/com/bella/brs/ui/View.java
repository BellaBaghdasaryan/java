package com.bella.brs.ui;

/**
 * @author Bella Baghdasaryan
 */
public interface View {
	public void refresh();
}