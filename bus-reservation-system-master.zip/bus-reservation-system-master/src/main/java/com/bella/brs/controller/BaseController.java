package com.bella.brs.controller;

/**
 * @author Bella Baghdasaryan
 */
public abstract class BaseController {}