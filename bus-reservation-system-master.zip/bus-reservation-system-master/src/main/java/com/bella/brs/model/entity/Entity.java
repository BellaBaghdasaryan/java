package com.bella.brs.model.entity;

import com.bella.brs.model.Model;

/**
 * @author Bella Baghdasaryan
 */
public interface Entity extends Model{}